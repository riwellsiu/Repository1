import sqlite3
from datetime import date
class user1:
    # 1. Create the constructor function
    def __init__(self, userID, firstName, lastName, email, hashedPassword, profileImage, location, joinDate, lastLogin ):
        self.__userID = userID
        self.__firstName = firstName
        self.__lastName = lastName
        self.__email = email
        self.__hashedPassword = hashedPassword
        self.__profileImage = profileImage
        self.__location = location
        self.__joinDate = joinDate
        self.__lastLogin = lastLogin

    @property
    def userID(self):
        return self.__userID

    @userID.setter
    def userID(self, value):
        # You can add validation logic here if needed
        self.__userID = value

    @property
    def firstName(self):
        return self.__firstName
    @firstName.setter
    def firstName(self, value):
        self.__firstName = value

    @property
    def lastName(self):
        return self.__lastName
    @lastName.setter
    def lastName(self, value):
        self.__lastName = value

    @property
    def email(self):
        return self.__email
    @email.setter
    def email(self, value):
        self.__email = value

    @property
    def hashedPassword(self):
        return self.__hashedPassword
    @hashedPassword.setter
    def hashedPassword(self, value):
        self.__hashedPassword = value

    @property
    def profileImage(self):
        return self.__profileImage
    @profileImage.setter
    def profileImage(self, value):
        self.__profileImage = value

    @property
    def location(self):
        return self.__location
    @location.setter
    def location(self, value):
        self.__location = value

    @property
    def joinDate(self):
        return self.__joinDate
    @joinDate.setter
    def joinDate(self, value):
        self.__joinDate = value

    @property
    def lastLogin(self):
        return self.__lastLogin
    @lastLogin.setter
    def lastLogin(self, value):
        self.__lastLogin = value

    @classmethod
    def saveauser(cls, firstName, lastName, email, hashedPassword, profileImage, location):
        #A. Make a connection to the database
        conn = None
        conn = sqlite3.connect( "mainframe.db")
        joinDate = date.today()
        lastLogin = date.today()
        #B. Write a SQL statement to insert a specific row (based on Title name)
        sql='INSERT INTO user (firstName, lastName, email, hashedPassword, profileImage, location, joinDate, lastLogin ) values (?,?,?,?,?,?,?,?)'

        # B. Create a workspace (aka Cursor)
        cur = conn.cursor()

        # C. Run the SQL statement from above and pass it 1 parameter for each ?
        cur.execute(sql, (firstName, lastName, email, hashedPassword, profileImage, location, joinDate,lastLogin))

        # D. Save the changes
        conn.commit()
        if conn:
            conn.close()

    @classmethod
    def updateprofileDB(self, userID, firstName, lastName, email, hashedPassword, profileImage, location):
        #A. Make a connection to the database
        conn = None
        conn = sqlite3.connect('mainframe.db')

        #B. Write a SQL statement to insert a specific row (based on Title name)
        sql='UPDATE user set firstname = ?, lastname=?, email = ?, hashedPassword = ?, profileImage = ?, location = ? where userID = ?'

        # B. Create a workspace (aka Cursor)
        cur = conn.cursor()

        # C. Run the SQL statement from above and pass it 1 parameter for each ?
        cur.execute(sql, (firstName, lastName, email, hashedPassword, profileImage, location, userID))

        # D. Save the changes
        conn.commit()
#get the information of one user
    @classmethod
    def getSingleUserList_DB(self,userID):
        conn = sqlite3.connect('mainframe.db')
        conn.row_factory = sqlite3.Row
        cursorObj = conn.cursor()
        userdict = []
        cursorObj.execute('SELECT * FROM user where userID = ?;',(userID,))
        rows = cursorObj.fetchall()
        for row in rows:
            m = {"userID" : row["userID"], "firstName" : row["firstName"], "lastName" : row["lastName"], "email" : row["email"], "hashedPassword" : row["hashedPassword"],"profileImage" : row["profileImage"], "location" : row["location"], "joinDate" : row["joinDate"] , "lastLogin" : row["lastLogin"] }
            userdict.append(m)
        return userdict
#get the information of all users
    @classmethod
    def getAllusers(cls):
        # A. Connection to the database
        conn = sqlite3.connect('mainframe.db')
        conn.row_factory = sqlite3.Row
        # B. Create a workspace (aka Cursor)
        cursorObj = conn.cursor()

        # D. Run the SQL Select statement to retive the data
        cursorObj.execute('SELECT firstName, lastName, email, hashedPassword, profileImage, location FROM user;')

        # E. Tell Pyton to 'fetch' all of the records and put them in
        #     a list called allRows
        allRows = cursorObj.fetchall()

        userListOfDictionaries = []

        for row in allRows:
            #m = {"name" : individualRow[0], "month": individualRow[1], "day":individualRow[2] }
           m = {"firstName" : row["firstName"], "lastName" : row["lastName"], "email" : row["email"], "hashedPassword" : row["hashedPassword"],"profileImage" : row["profileImage"], "location" : row["location"] }
           userListOfDictionaries.append(m)

        if conn:
            conn.close()

        return userListOfDictionaries
#set up the last login time for a user
    @classmethod
    def updatelastloginDB(self, userID):
        #A. Make a connection to the database
        conn = None
        conn = sqlite3.connect('mainframe.db')

        #B. Write a SQL statement to insert a specific row (based on Title name)
        sql='UPDATE user set lastLogin = ? where userID = ?'
        lastlogin = date.today()
        # B. Create a workspace (aka Cursor)
        cur = conn.cursor()

        # C. Run the SQL statement from above and pass it 1 parameter for each ?
        cur.execute(sql, (lastlogin, userID))

        # D. Save the changes
        conn.commit()
#retrieve all of the usernsames (emails)##
    @classmethod
    def getAllemails(cls):
        # A. Connection to the database
        conn = sqlite3.connect('mainframe.db')
        conn.row_factory = sqlite3.Row
        # B. Create a workspace (aka Cursor)
        cursorObj = conn.cursor()
        # D. Run the SQL Select statement to retive the data
        cursorObj.execute('SELECT email FROM user;')

        # E. Tell Pyton to 'fetch' all of the records and put them in
        #     a list called allRows
        allRows = cursorObj.fetchall()

        userListOfemails = []

        for row in allRows:
            #m = {"name" : individualRow[0], "month": individualRow[1], "day":individualRow[2] }
           m = row["email"]
           userListOfemails.append(m)

        if conn:
            conn.close()

        return userListOfemails
##get a singular user id for links and forms##
    @classmethod
    def getsingleuserid(cls,email):
        # A. Connection to the database
        conn = sqlite3.connect('mainframe.db')
        conn.row_factory = sqlite3.Row
        # B. Create a workspace (aka Cursor)
        cursorObj = conn.cursor()
        # D. Run the SQL Select statement to retive the data
        cursorObj.execute('SELECT userID FROM user WHERE email = ?;',(email,))

        # E. Tell Pyton to 'fetch' all of the records and put them in
        #     a list called allRows
        allRows = cursorObj.fetchall()
        m = ""
        for row in allRows:
            #m = {"name" : individualRow[0], "month": individualRow[1], "day":individualRow[2] }
           m = row["userID"]


        if conn:
            conn.close()

        return m
##passign in the users email to get their id##
    @classmethod
    def getuserIDfromemail(cls,email):
        conn = sqlite3.connect('mainframe.db')
        conn.row_factory = sqlite3.Row
        cur = conn.cursor()
        sql = 'SELECT userID FROM user WHERE email = ?;'
        cur.execute(sql, (email,))
        allRows = cur.fetchall()

        usersid = []

        for row in allRows:
            #m = {"name" : individualRow[0], "month": individualRow[1], "day":individualRow[2] }
           m = row["userID"]
           usersid.append(m)
        usersid1 = usersid[0]
        if conn:
            conn.close()
        return usersid1
        #when i want to get all info on a user based on their email##
    @classmethod
    def getallfromuserid(cls,email):
        conn = sqlite3.connect('mainframe.db')
        conn.row_factory = sqlite3.Row
        cur = conn.cursor()
        sql = 'SELECT * FROM user WHERE email = ?;'
        cur.execute(sql, (email,))
        allRows = cur.fetchall()

        usersid = []

        for row in allRows:
            #m = {"name" : individualRow[0], "month": individualRow[1], "day":individualRow[2] }
           m = {"userID" : row["userID"],"firstName" : row["firstName"], "lastName" : row["lastName"], "email" : row["email"], "hashedPassword" : row["hashedPassword"],"profileImage" : row["profileImage"], "location" : row["location"] }
           usersid.append(m)

        if conn:
            conn.close()
        return usersid
##this will pull the top three users by the average of their reviews in stars##
    @classmethod
    def getbestusers(cls):
        # A. Connection to the database
        conn = sqlite3.connect('mainframe.db')
        conn.row_factory = sqlite3.Row
        # B. Create a workspace (aka Cursor)
        cursorObj = conn.cursor()

        # D. Run the SQL Select statement to retive the data
        cursorObj.execute('SELECT r.reviewedUserId, AVG(r.rating) AS average_review_value, u.firstName, u.lastName, u.email FROM review r INNER JOIN user u ON r.reviewedUserId = u.userID GROUP BY r.reviewedUserId ORDER BY average_review_value DESC LIMIT 3;')

        # E. Tell Pyton to 'fetch' all of the records and put them in
        #     a list called allRows
        allRows = cursorObj.fetchall()

        userListOfDictionaries = []

        for row in allRows:
            #m = {"name" : individualRow[0], "month": individualRow[1], "day":individualRow[2] }
           m = {"average_review_value" : row["average_review_value"], "lastName" : row["lastName"], "firstName" : row["firstName"], "email" : row["email"]}
           userListOfDictionaries.append(m)

        if conn:
            conn.close()

        return userListOfDictionaries
##this deletes a user out of the user#
    @classmethod
    def deleteUser(self, userID):
        conn = sqlite3.connect("mainframe.db")
        conn.row_factory = sqlite3.Row
        sql="DELETE FROM user WHERE userID=?"
        cur = conn.cursor()
        cur.execute(sql, (userID,))
        conn.commit()



##class for the listings table##
class listing:
    def __init__(self, listingID, userID, title, description, images, category, datePosted, status):
        self.__listingID = listingID
        self.__userID = userID
        self.__title = title
        self.__description = description
        self.__images = images
        self.__category = category
        self.__datePosted = datePosted
        self.__status = status

    @property
    def listingID(self):
        return self.__listingID
    @listingID.setter
    def listingID(self, value):
        self.__listingID = value

    @property
    def userID(self):
        return self.__userID
    @userID.setter
    def userID(self, value):
        self.__userID = value

    @property
    def title(self):
        return self.__title
    @title.setter
    def title(self, value):
        self.__title = value

    @property
    def description(self):
        return self.__description
    @description.setter
    def description(self, value):
        self.__description = value

    @property
    def images(self):
        return self.__images
    @images.setter
    def images(self, value):
        self.__images = value

    @property
    def category(self):
        return self.__category
    @category.setter
    def category(self, value):
        self.__category = value

    @property
    def datePosted(self):
        return self.__datePosted
    @datePosted.setter
    def datePosted(self, value):
        self.__datePosted = value

    @property
    def status(self):
        return self.__status
    @status.setter
    def status(self, value):
        self.__status = value
##adds a listing and its data into the database##
    @classmethod
    def addListing(cls, userID, title, description, images, category):
        conn = None
        conn = sqlite3.connect("mainframe.db")
        datePosted = date.today()
        status = "Available"
        sql="INSERT INTO listing(userID, title, description, images, category, datePosted, status) values (?, ?,?,?,?,?,?)"

        cur = conn.cursor()
        cur.execute(sql, (userID, title, description, images, category, datePosted, status))

        conn.commit()
        if conn:
            conn.close()
##updates the listing in case someone wants to editit##
    @classmethod
    def updateListing(self, listingID, title, description, images, category, status):
        conn = None
        conn = sqlite3.connect("mainframe.db")

        sql="UPDATE listing SET title=?, description = ?, images = ?, category = ?, status = ? WHERE listingID = ?"

        cur = conn.cursor()
        cur.execute(sql, (title, description, images, category, status, listingID))

        conn.commit()
## given a listings id, we can get all of the applicable info including names##
    @classmethod
    def getListing(self,listingID):
        conn = sqlite3.connect("mainframe.db")
        conn.row_factory = sqlite3.Row
        cursorObj = conn.cursor()
        listingDict = []
        cursorObj.execute("SELECT user.email,listing.userID as userID, listing.listingID as listingID, user.firstName as firstName, user.lastname as lastName, user.location as location, listing.title as title, listing.description as description, listing.images as images, listing.category as category, listing.datePosted as datePosted, listing.status as status FROM user, listing WHERE user.userID = listing.userID and listing.listingID = ?;",(listingID, ))
        # cursorObj.execute("SELECT * FROM listing where listingID = ?;",(listingID, ))

        rows = cursorObj.fetchall()


        for row in rows:
            m = {"email": row["email"],"userID": row["userID"], "listingID" : row["listingID"], "title" : row["title"], "description" : row["description"], "images" : row["images"],"category" : row["category"], "datePosted" : row["datePosted"], "status" : row["status"], "firstName" : row["firstName"], "lastName" : row["lastName"], "location" : row["location"]}
            listingDict.append(m)


        return listingDict


##this retrieves the latest three
    @classmethod
    def getNewestListings(self):
        conn = sqlite3.connect("mainframe.db")
        conn.row_factory = sqlite3.Row
        cursorObj = conn.cursor()
        listingDict = []
        cursorObj.execute("SELECT user.email, listing.userID AS userID, listing.listingID AS listingID, user.firstName AS firstName, user.lastname AS lastName, user.location AS location, listing.title AS title, listing.description AS description, listing.images AS images, listing.category AS category, listing.datePosted AS datePosted, listing.status AS status FROM user, listing WHERE user.userID = listing.userID ORDER BY listing.datePosted DESC LIMIT 3;")

        rows = cursorObj.fetchall()


        for row in rows:
            m = {"email": row["email"],"userID": row["userID"], "listingID" : row["listingID"], "title" : row["title"], "description" : row["description"], "images" : row["images"],"category" : row["category"], "datePosted" : row["datePosted"], "status" : row["status"], "firstName" : row["firstName"], "lastName" : row["lastName"], "location" : row["location"]}
            listingDict.append(m)


        return listingDict















    @classmethod
    def myListing(self,userID):
        conn = sqlite3.connect("mainframe.db")
        conn.row_factory = sqlite3.Row
        cursorObj = conn.cursor()
        listingDict = []
        cursorObj.execute("SELECT * FROM listing WHERE userID = ?;",(userID, ))
        rows = cursorObj.fetchall()

        for row in rows:
            m = {"listingID" : row["listingID"], "title" : row["title"], "description" : row["description"], "category" : row["category"], "datePosted" : row["datePosted"], "status" : row["status"]}
            listingDict.append(m)

        return listingDict

    @classmethod
    def getMyListing(self,listingID):
        conn = sqlite3.connect("mainframe.db")
        conn.row_factory = sqlite3.Row
        cursorObj = conn.cursor()
        listingDict = []
        cursorObj.execute("SELECT listing.listingID as listingID, user.firstName as firstName, user.lastname as lastName, user.location as location, listing.title as title, listing.description as description, listing.images as images, listing.category as category, listing.datePosted as datePosted, listing.status as status FROM user, listing WHERE user.userID = listing.userID and listing.listingID = ?;",(listingID, ))
        # cursorObj.execute("SELECT * FROM listing where listingID = ?;",(listingID, ))

        rows = cursorObj.fetchall()

        for row in rows:
            m = {"listingID" : row["listingID"], "title" : row["title"], "description" : row["description"], "images" : row["images"],"category" : row["category"], "datePosted" : row["datePosted"], "status" : row["status"], "firstName" : row["firstName"], "lastName" : row["lastName"], "location" : row["location"]}
            listingDict.append(m)


        return listingDict


    @classmethod
    def getAllListings(cls):
        conn = sqlite3.connect("mainframe.db")
        conn.row_factory = sqlite3.Row
        cursorObj = conn.cursor()
        cursorObj.execute("SELECT * FROM listing;")

        allRows = cursorObj.fetchall()

        fullListingDict = []

        for row in allRows:
           m = {"listingID" : row["listingID"], "userID" : row["userID"], "title" : row["title"], "description" : row["description"], "images" : row["images"],"category" : row["category"], "datePosted" : row["datePosted"], "status" : row["status"]}
           fullListingDict.append(m)

        if conn:
            conn.close()

        return fullListingDict
    @classmethod
    def getfilteredListings(cls,category):
        conn = sqlite3.connect("mainframe.db")
        conn.row_factory = sqlite3.Row
        cursorObj = conn.cursor()
        cursorObj.execute("SELECT * FROM listing WHERE category = ?;",(category, ))

        allRows = cursorObj.fetchall()

        fullListingDict = []

        for row in allRows:
           m = {"listingID" : row["listingID"], "userID" : row["userID"], "title" : row["title"], "description" : row["description"], "images" : row["images"],"category" : row["category"], "datePosted" : row["datePosted"], "status" : row["status"]}
           fullListingDict.append(m)

        if conn:
            conn.close()

        return fullListingDict


    @classmethod
    def deleteListing(self, listingID):
        conn = sqlite3.connect("mainframe.db")
        conn.row_factory = sqlite3.Row
        sql="DELETE FROM listing WHERE listingID=?"
        cur = conn.cursor()
        cur.execute(sql, (listingID,))
        conn.commit()

    @classmethod
    def getsingleuseridfromlistid(cls,listingID):
        # A. Connection to the database
        conn = sqlite3.connect('mainframe.db')
        conn.row_factory = sqlite3.Row
        # B. Create a workspace (aka Cursor)
        cursorObj = conn.cursor()
        # D. Run the SQL Select statement to retive the data
        cursorObj.execute('SELECT userID FROM listing WHERE listingID = ?;',(listingID,))

        # E. Tell Pyton to 'fetch' all of the records and put them in
        #     a list called allRows
        allRows = cursorObj.fetchall()
        m = ""
        for row in allRows:
            #m = {"name" : individualRow[0], "month": individualRow[1], "day":individualRow[2] }
           m = row["userID"]


        if conn:
            conn.close()

        return m



class Category:
    def __init__(self, categoryID, name, description):
        self.__categoryID = categoryID
        self.__name = name
        self.__description = description

    @property
    def categoryID(self):
        return self.__categoryID
    @categoryID.setter
    def categoryID(self, value):
        self.__categoryID = value

    @property
    def name(self):
        return self.__name
    @name.setter
    def name(self, value):
        self.__name = value

    @property
    def description(self):
        return self.__description
    @description.setter
    def description(self, value):
        self.__description = value

    @classmethod
    def addCategory(cls, name, description):
        conn = None
        conn = sqlite3.connect("mainframe.db")

        sql="INSERT INTO category(name, description) values (?,?)"

        cur = conn.cursor()
        cur.execute(sql, (name, description))

        conn.commit()
        if conn:
            conn.close()

    @classmethod
    def updateCategory(self, categoryID, name, description):
        conn = None
        conn = sqlite3.connect("mainframe.db")

        sql="UPDATE category SET name = ?, description = ? WHERE categoryID = ?"

        cur = conn.cursor()
        cur.execute(sql, (name, description, categoryID))

        conn.commit()

        if conn:
            conn.close()

    @classmethod
    def getAllCategories(cls):
        conn = sqlite3.connect("mainframe.db")
        conn.row_factory = sqlite3.Row
        cursorObj = conn.cursor()
        cursorObj.execute("SELECT * FROM category;")

        allRows = cursorObj.fetchall()

        fullCategoryDict = []

        for row in allRows:
           m = {"categoryID": row["categoryID"], "name" : row["name"], "description" : row["description"]}
           fullCategoryDict.append(m)

        if conn:
            conn.close()

        return fullCategoryDict

    @classmethod
    def getAllCategories2(cls):
        conn = sqlite3.connect("mainframe.db")
        conn.row_factory = sqlite3.Row
        cursorObj = conn.cursor()
        cursorObj.execute("SELECT * FROM category;")

        allRows = cursorObj.fetchall()

        fullCategoryDict = []

        for row in allRows:
           m = row["name"]
           fullCategoryDict.append(m)

        if conn:
            conn.close()

        return fullCategoryDict

    @classmethod
    def viewCategory(self,categoryID):
        conn = sqlite3.connect("mainframe.db")
        conn.row_factory = sqlite3.Row
        cursorObj = conn.cursor()
        categoryDict = []
        cursorObj.execute("SELECT * FROM category WHERE categoryID = ?;",(categoryID, ))
        rows = cursorObj.fetchall()

        for row in rows:
            m = {"categoryID" : row["categoryID"], "name" : row["name"], "description" : row["description"]}
            categoryDict.append(m)

        return categoryDict

    @classmethod
    def deleteCategory(self, categoryID):
        conn = sqlite3.connect("mainframe.db")
        conn.row_factory = sqlite3.Row
        sql="DELETE FROM category WHERE categoryID=?"
        cur = conn.cursor()
        cur.execute(sql, (categoryID,))
        conn.commit()

class review:
    def __init__(self, reviewID, reviewerID, reviewedUserID, rating, comment, datePosted):
        self.__reviewID = reviewID
        self.__reviewerID = reviewerID
        self.__reviewedUserID = reviewedUserID
        self.__rating = rating
        self.__comment = comment
        self.__datePosted = datePosted

    @property
    def reviewID(self):
        return self.__reviewID
    @reviewID.setter
    def reviewID(self, value):
        self.__reviewID = value

    @property
    def reviewerID(self):
        return self.__reviewerID
    @reviewerID.setter
    def reviewerID(self, value):
        self.__reviewerID = value

    @property
    def reviewedUserID(self):
        return self.__reviewedUserID
    @reviewedUserID.setter
    def reviewedUserID(self, value):
        self.__reviewedUserID = value

    @property
    def rating(self):
        return self.__rating
    @rating.setter
    def rating(self, value):
        self.__rating = value

    @property
    def comment(self):
        return self.__comment
    @comment.setter
    def comment(self, value):
        self.__comment = value

    @property
    def datePosted(self):
        return self.__datePosted
    @datePosted.setter
    def datePosted(self, value):
        self.__datePosted = value

    @classmethod
    def addReview(cls, reviewerID, reviewedUserID, rating, comment):
        conn = None
        conn = sqlite3.connect("mainframe.db")

        datePosted = date.today()
        sql="INSERT INTO review(reviewerID, reviewedUserID, rating, comment, datePosted) values (?,?,?,?,?)"

        cur = conn.cursor()
        cur.execute(sql, (reviewerID, reviewedUserID, rating, comment, datePosted))

        conn.commit()
        if conn:
            conn.close()

    @classmethod
    def getAllReviews(cls):
        conn = sqlite3.connect("mainframe.db")
        conn.row_factory = sqlite3.Row
        cursorObj = conn.cursor()
        cursorObj.execute("SELECT (SELECT email FROM user WHERE userID = review.reviewerID) as revieweremail,*, (SELECT email FROM user WHERE userID = review.reviewedUserID) as revieweeEmail FROM review ")

        allRows = cursorObj.fetchall()

        fullReviewDict = []

        for row in allRows:
           m = {"reviewID" : row["reviewID"],"reviewerID" : row["reviewerID"], "reviewedUserID" : row["reviewedUserID"], "rating" : row["rating"], "comment" : row["comment"], "datePosted" : row["datePosted"], "revieweremail" : row["revieweremail"],"revieweeEmail" : row["revieweeEmail"] }
           fullReviewDict.append(m)

        if conn:
            conn.close()

        return fullReviewDict

    @classmethod
    def viewreview(self,reviewID):
        conn = sqlite3.connect("mainframe.db")
        conn.row_factory = sqlite3.Row
        cursorObj = conn.cursor()
        categoryDict = []
        cursorObj.execute("SELECT (SELECT email FROM user WHERE userID = review.reviewerID) as revieweremail,*, (SELECT email FROM user WHERE userID = review.reviewedUserID) as revieweeEmail FROM review WHERE review.reviewID = ?",(reviewID, ))
        rows = cursorObj.fetchall()

        for row in rows:
            m = {"reviewID" : row["reviewID"], "reviewerID" : row["reviewerID"], "reviewedUserID" : row["reviewedUserID"], "rating" : row["rating"], "comment" : row["comment"], "datePosted" : row["datePosted"], "revieweremail" : row["revieweremail"],"revieweeEmail" : row["revieweeEmail"] }
            categoryDict.append(m)

        return categoryDict

    @classmethod
    def getmyreviews(self,userID):
        conn = sqlite3.connect("mainframe.db")
        conn.row_factory = sqlite3.Row
        cursorObj = conn.cursor()
        categoryDict = []
        cursorObj.execute("SELECT (SELECT email FROM user WHERE userID = review.reviewerID) as revieweremail,*, (SELECT email FROM user WHERE userID = review.reviewedUserID) as revieweeEmail FROM review WHERE review.reviewerID = ?",(userID, ))
        rows = cursorObj.fetchall()

        for row in rows:
            m = {"reviewID" : row["reviewID"], "reviewerID" : row["reviewerID"], "reviewedUserID" : row["reviewedUserID"], "rating" : row["rating"], "comment" : row["comment"], "datePosted" : row["datePosted"], "revieweremail" : row["revieweremail"],"revieweeEmail" : row["revieweeEmail"] }
            categoryDict.append(m)

        return categoryDict
    @classmethod
    def updatereview(self, reviewID, description, rating):
        conn = None
        conn = sqlite3.connect("mainframe.db")

        sql="UPDATE review SET comment = ?, rating = ? WHERE reviewID = ?"

        cur = conn.cursor()
        cur.execute(sql, (description, rating, reviewID))

        conn.commit()

        if conn:
            conn.close()
    @classmethod
    def deletereview(self, reviewID):
        conn = sqlite3.connect("mainframe.db")
        conn.row_factory = sqlite3.Row
        sql="DELETE FROM review WHERE reviewID=?"
        cur = conn.cursor()
        cur.execute(sql, (reviewID,))
        conn.commit()

    @classmethod
    def filterreviews(self,email):
        conn = sqlite3.connect("mainframe.db")
        conn.row_factory = sqlite3.Row
        sql="SELECT * FROM user u INNER JOIN review r ON u.userID = r.reviewedUserID WHERE u.email = ?;"
        cur = conn.cursor()
        cur.execute(sql, (email,))
        rows = cur.fetchall()

        if len(rows) == 0:
            m = ""
        else:
            for row in rows:
                m = row["reviewedUserID"]

        return m



    @classmethod
    def getAllReviewsSinglePerson(cls,reviewedID):
        conn = sqlite3.connect("mainframe.db")
        conn.row_factory = sqlite3.Row
        cursorObj = conn.cursor()
        cursorObj.execute("SELECT (SELECT email FROM user WHERE userID = review.reviewerID) as revieweremail,*, (SELECT email FROM user WHERE userID = review.reviewedUserID) as revieweeEmail FROM review WHERE review.reviewedUserID = ?",(reviewedID, ))

        allRows = cursorObj.fetchall()

        fullReviewDict = []

        for row in allRows:
           m = {"reviewID" : row["reviewID"],"reviewerID" : row["reviewerID"], "reviewedUserID" : row["reviewedUserID"], "rating" : row["rating"], "comment" : row["comment"], "datePosted" : row["datePosted"], "revieweremail" : row["revieweremail"],"revieweeEmail" : row["revieweeEmail"] }
           fullReviewDict.append(m)

        if conn:
            conn.close()

        return fullReviewDict

    @classmethod
    def reviewaverage(self,userID):
        conn = sqlite3.connect("mainframe.db")
        conn.row_factory = sqlite3.Row
        sql="SELECT AVG(rating) AS average_review_value FROM review WHERE reviewedUserID = ?;"
        cur = conn.cursor()
        cur.execute(sql, (userID,))
        rows = cur.fetchall()

        if len(rows) == 0:
            m = ""
        else:
            for row in rows:
                m = row["average_review_value"]

        return m






class message:
    def __init__(self, messageID, senderID, receiverID, listingID, content, sendDate, isRead):
        self.__messageID = messageID
        self.__senderID = senderID
        self.__receiverID = receiverID
        self.__listingID = listingID
        self.__content = content
        self.__sendDate = sendDate
        self.__isRead = isRead

    @property
    def messageID(self):
        return self.__messageID
    @messageID.setter
    def messageID(self, value):
        self.__messageID = value

    @property
    def senderID(self):
        return self.__senderID
    @senderID.setter
    def senderID(self, value):
        self.__senderID = value

    @property
    def receiverID(self):
        return self.__receiverID
    @receiverID.setter
    def receiverID(self, value):
        self.__receiverID = value

    @property
    def listingID(self):
        return self.__listingID
    @listingID.setter
    def listingID(self, value):
        self.__listingID = value

    @property
    def content(self):
        return self.__content
    @content.setter
    def content(self, value):
        self.__content = value

    @property
    def sendDate(self):
        return self.__sendDate
    @sendDate.setter
    def sendDate(self, value):
        self.__sendDate = value

    @property
    def isRead(self):
        return self.__isRead
    @isRead.setter
    def isRead(self, value):
        self.__isRead = value

    @classmethod
    def addMessage(cls, senderID, receiverID, listingID, content):
        conn = None
        conn = sqlite3.connect("mainframe.db")

        sendDate = date.today()
        isRead = False
        sql="INSERT INTO message(senderID, receiverID, listingID, content, sendDate, isRead) values (?,?,?,?,?,?)"

        cur = conn.cursor()
        cur.execute(sql, (senderID, receiverID, listingID, content, sendDate, isRead))

        conn.commit()
        if conn:
            conn.close()

    @classmethod
    def updateMessage(self, content, sendDate, isRead):
        conn = None
        conn = sqlite3.connect("mainframe.db")

        sendDate = date.today()
        isRead = False
        sql="UPDATE message set content = ?, sendDate=?, isRead = ? where messageID = ?"

        cur = conn.cursor()
        cur.execute(sql, (content, sendDate, isRead))

        conn.commit()

        if conn:
            conn.close()

    @classmethod
    def getMessage(self, messageID):
        conn = sqlite3.connect("mainframe.db")
        conn.row_factory = sqlite3.Row
        cursorObj = conn.cursor()
        messageDict = []
        cursorObj.execute("SELECT * FROM message where messageID = ?;",(messageID))

        rows = cursorObj.fetchall()

        for row in rows:
            m = {"senderID" : row["senderID"], "receiverID" : row["receiverID"], "listingID" : row["listingID"], "content" : row["content"], "sendDate" : row["sendDate"],"isRead" : row["isRead"]}
            messageDict.append(m)

        return messageDict


    @classmethod
    def getmyMessages(cls,userID):
        conn = sqlite3.connect("mainframe.db")
        conn.row_factory = sqlite3.Row
        cursorObj = conn.cursor()
        cursorObj.execute("SELECT * FROM message WHERE recieverID = ?;",(userID))

        allRows = cursorObj.fetchall()

        fullMessageDict = []

        for row in allRows:
           m = {"senderID" : row["senderID"], "receiverID" : row["receiverID"], "listingID" : row["listingID"], "content" : row["content"], "sendDate" : row["sendDate"],"isRead" : row["isRead"]}
           fullMessageDict.append(m)

        if conn:
            conn.close()

        return fullMessageDict

    @classmethod
    def getmycontacts(cls,userID):
        conn = sqlite3.connect("mainframe.db")
        conn.row_factory = sqlite3.Row
        cursorObj = conn.cursor()
        cursorObj.execute('SELECT email,firstName,lastName,profileImage, message.senderID, message.receiverID FROM user INNER JOIN message ON user.userID = message.receiverID OR user.userID = message.senderID WHERE (message.receiverID = ? OR message.senderID = ?) AND (userID != ?) GROUP BY email;',(userID,userID,userID))

        allRows = cursorObj.fetchall()

        fullMessageDict = []

        for row in allRows:
           m = {"email" : row["email"], "firstName" : row["firstName"], "lastName" : row["lastName"], "profileImage" : row["profileImage"], "senderID" : row["senderID"],"receiverID" : row["receiverID"]}
           fullMessageDict.append(m)

        if conn:
            conn.close()

        return fullMessageDict
    @classmethod
    def getmyunreads(cls,userID):
        conn = sqlite3.connect("mainframe.db")
        conn.row_factory = sqlite3.Row
        cursorObj = conn.cursor()
        cursorObj.execute('SELECT m.senderID, u.userID, u.email, u.firstName, u.lastName, COUNT(*) AS unread_count FROM message m INNER JOIN user u ON m.senderID = u.userID WHERE m.isRead = 0 AND m.receiverID = ? GROUP BY m.senderID, u.email, u.firstname, u.lastname;',(userID,))
        allRows = cursorObj.fetchall()

        fullMessageDict = []

        for row in allRows:
           m = {"userID" : row["userID"], "firstName" : row["firstName"],"lastName" : row["lastName"], "email" : row["email"], "unread_count" : row["unread_count"]}
           fullMessageDict.append(m)

        if conn:
            conn.close()

        return fullMessageDict

    @classmethod
    def gettheconvo(cls, userID, senderID):
        conn = sqlite3.connect("mainframe.db")
        conn.row_factory = sqlite3.Row
        cursorObj = conn.cursor()

        # Retrieve messages and categorize them as "You" or "Them"
        cursorObj.execute('''
            SELECT
                m.messageID, m.senderID, m.receiverID, m.listingID, m.content,
                m.sendDate, m.isRead, u.firstName, u.lastName,
                CASE
                    WHEN m.senderID = ? THEN 'You'
                    ELSE 'Them'
                END AS messageCategory
            FROM message m
            LEFT JOIN user u on m.senderID = u.userID
            WHERE (m.senderID = ? AND m.receiverID = ?) OR (m.senderID = ? AND m.receiverID = ?)
        ''', (userID, userID, senderID, senderID, userID))

        allRows = cursorObj.fetchall()

        fullMessageDict = []

        for row in allRows:
            m = {
                "messageID": row["messageID"],
                "senderID": row["senderID"],
                "receiverID": row["receiverID"],
                "listingID": row["listingID"],
                "content": row["content"],
                "sendDate": row["sendDate"],
                "isRead": row["isRead"],
                "firstName": row["firstName"],
                "lastName": row["lastName"],
                "messageCategory": row["messageCategory"]
            }
            fullMessageDict.append(m)

        if conn:
            conn.close()

        return fullMessageDict

    @classmethod
    def updatemessagesasread(self, senderID,userID):
        #A. Make a connection to the database
        conn = None
        conn = sqlite3.connect('mainframe.db')

        #B. Write a SQL statement to insert a specific row (based on Title name)
        sql='UPDATE message SET isRead = 1 WHERE (message.senderID = ? AND message.receiverID = ?)'

        # B. Create a workspace (aka Cursor)
        cur = conn.cursor()

        # C. Run the SQL statement from above and pass it 1 parameter for each ?
        cur.execute(sql, (userID,senderID))

        # D. Save the changes
        conn.commit()
